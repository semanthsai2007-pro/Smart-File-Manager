numbers = [1,2,3,4,5,6,7,8]
    
even = [x for x in numbers if x % 2 == 0]
print("Even numbers:", even)
square = [x * x for x in numbers]
print("Square numbers:", square)
books = ["Python", "Data Science", "AI", "Computer Programming"]
long_books = [x for x in books if len(x) > 10]
print("Books with more than 10 characters:", long_books)
even_square = [x * x for x in numbers if x % 2 == 0]
print("Square of even numbers:", even_square)
