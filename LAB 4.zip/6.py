n = int(input("Enter the number of list of items you want to add: "))
grocery_list = []

for i in range(0,n):
    print(f"Enter The Item {i+1}:")
    v = input()
    grocery_list.append(v)

print("Initial list:", grocery_list)

add_item = input("Enter an item to add: ")
grocery_list.append(add_item)

remove_item = input("Enter an item to remove: ")
if remove_item in grocery_list:
    grocery_list.remove(remove_item)
    print(f"Removed '{remove_item}'.")
else:
    print(f"'{remove_item}' not found in the list.")

print("\nFinal Shopping List:")
for item in grocery_list:
    print(item)
