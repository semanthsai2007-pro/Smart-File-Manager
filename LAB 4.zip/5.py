n = int(input("Enter The Number of Values: "))
unique_numbers = []

for i in range(n):
    x = int(input("Enter Value: "))
    if x not in unique_numbers:
        unique_numbers.append(x)
print("Unique Values: ",unique_numbers)
