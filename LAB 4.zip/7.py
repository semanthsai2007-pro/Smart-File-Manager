books = ["Python Programming", "Data Structures", "Computer Networks", "Database Systems"]

while (1):
    print("\nLibrary Management System")
    print("1. Display all books")
    print("2. Add a new book")
    print("3. Insert a book at a specific position")
    print("4. Check availability of a book")
    print("5. Count occurrences of a book")
    print("6. Remove a book")
    print("7. Sort books alphabetically")
    print("8. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        print("\nBooks available in library:")
        if len(books) == 0:
            print("No books available.")
        else:
            for i, book in enumerate(books, start=1):
                print(i, ".", book)

    elif choice == "2":
        book = input("Enter the name of the new book: ")
        books.append(book)
        print("Book added successfully.")

    elif choice == "3":
        print("\nCurrent book list:")
        for i, book in enumerate(books):
            print(i, "-", book)

        book = input("Enter the book name to insert: ")
        position = int(input("Enter the position (index): "))

        books.insert(position, book)
        print("Book inserted successfully.")

    elif choice == "4":
        book = input("Enter the book name to search: ")

        if book in books:
            print("Book is available.")
        else:
            print("Book not found.")

    elif choice == "5":
        book = input("Enter the book name to count: ")

        if book in books:
            print("Number of occurrences:", books.count(book))
        else:
            print("Book not found.")

    elif choice == "6":
        book = input("Enter the book name to remove: ")

        if book in books:
            books.remove(book)
            print("Book removed successfully.")
        else:
            print("Book not found.")

    elif choice == "7":
        books.sort()
        print("\nBooks sorted alphabetically:")

        for i, book in enumerate(books, start=1):
            print(i, ".", book)

    elif choice == "8":
        print("Exiting Library Management System.")
        break

    else:
        print("Invalid choice. Please enter a number between 1 and 8.")
