s = input()
result = ""
for i in range(len(s)):
    char = s[i]
    code = 0
    c = 0
    while True:
        if chr(c) == char:
            code = c
            break
        c += 1
    result += chr(code + 1)
print(result)
