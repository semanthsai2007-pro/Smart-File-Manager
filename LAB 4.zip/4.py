days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
temps = [float(input(f"Enter temperature for {day}: ")) for day in days]

max_temp, min_temp = max(temps), min(temps)
max_day = days[temps.index(max_temp)]
min_day = days[temps.index(min_temp)]

print(f"\nMax: {max_temp}°C on {max_day}")
print(f"Min: {min_temp}°C on {min_day}")

