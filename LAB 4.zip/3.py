n = int(input("Enter The Number of Elements: "))
list=[]
for i in range(0,n):
    print(f"Enter The Value {i+1}: ")
    value = int(input())
    list.append(value)
print(list)
